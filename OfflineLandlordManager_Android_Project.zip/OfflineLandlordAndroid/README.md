# Offline Landlord Rent Manager

Android WebView wrapper for the supplied standalone offline landlord management app.
The HTML is packaged locally in the APK. The app requests no INTERNET permission.

## Build
Use Android Gradle Plugin 8.6.1, Gradle 8.7, JDK 17, Android SDK 35.
Run `gradle assembleDebug`. APK: `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow at `.github/workflows/build-apk.yml` builds this APK on pushes to `main` or via manual workflow dispatch.
