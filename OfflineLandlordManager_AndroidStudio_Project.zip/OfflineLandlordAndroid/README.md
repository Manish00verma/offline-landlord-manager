# Offline Landlord Manager — Android Studio project

This is a native Android WebView-shell project with the app interface bundled locally in `app/src/main/assets/index.html`. The installed app does not request the Android INTERNET permission and loads no remote content.

## Features in this project
- Multiple properties and tenant/room records
- Individual tenant meter readings and a separate common-area meter per property
- Equal common-area charge allocation across active tenants in the property
- Monthly rent and electricity bills, additional charges, partial/full payment entries
- Carry-forward of unpaid balances through the tenant's chronological bill ledger
- Previous meter reading auto-filled from the latest earlier saved reading
- Individual tenant ledger with monthly charges, payments and balances
- JSON backup/restore and CSV bill export
- Data stored locally in the app's WebView storage

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`OfflineLandlordAndroid`) in Android Studio.
3. Allow Android Gradle Plugin / Android SDK components to install if prompted. These are build-time tools; the finished app itself is offline.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create the APK under `app/build/outputs/apk/debug/`.
6. Copy the APK to your Android phone and install it. If Android asks, allow installation from that file manager/browser.

## Offline and privacy notes
- The manifest intentionally has no `INTERNET` permission.
- All tenant/property/billing data is stored locally on the phone.
- Use Backup regularly. Android app data is private to the app; the backup/export file is saved to the app's Documents directory by the included Android bridge.
- Uninstalling the app removes its local database/storage. Export a backup first.
- This is a source project, not a compiled APK. It has not been compiled or device-tested in this environment because Android SDK/Gradle are unavailable here.

## Accounting behaviour
- On bill generation, previous unpaid balance is carried into the opening balance. Recalculating a prior month's bill/payment recalculates later tenant balances in chronological order.
- Previous individual/common meter values are prefilled from the latest earlier month saved. Users can edit the prefilled value when correcting a meter record.
- Common meter charges are divided equally among tenants active in that property for that billing month when bills are generated. Generate/re-generate bills after changing readings or tenant occupancy.
